import sys
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QDoubleSpinBox

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("Question 4")
window.setGeometry(300, 200, 400, 290)

label_bill = QLabel("Bill Amount:", window)
label_bill.setGeometry(30, 30, 150, 30)

bill_input = QDoubleSpinBox(window)
bill_input.setGeometry(190, 30, 170, 30)
bill_input.setRange(0, 100000)

label_tip_percent = QLabel("Tip Percentage (%):", window)
label_tip_percent.setGeometry(30, 75, 150, 30)

tip_percent_input = QDoubleSpinBox(window)
tip_percent_input.setGeometry(190, 75, 170, 30)
tip_percent_input.setRange(10, 20)
tip_percent_input.setValue(15)

calculate_button = QPushButton("Calculate", window)
calculate_button.setGeometry(30, 125, 330, 35)

label_tip_amount = QLabel("Tip Amount:", window)
label_tip_amount.setGeometry(30, 180, 150, 30)

tip_amount_display = QDoubleSpinBox(window)
tip_amount_display.setGeometry(190, 180, 170, 30)
tip_amount_display.setRange(0, 100000)
tip_amount_display.setReadOnly(True)
tip_amount_display.setStyleSheet("background-color: gray;")

label_total = QLabel("Total to Pay:", window)
label_total.setGeometry(30, 225, 150, 30)

total_display = QDoubleSpinBox(window)
total_display.setGeometry(190, 225, 170, 30)
total_display.setRange(0, 100000)
total_display.setReadOnly(True)
total_display.setStyleSheet("background-color: gray;")

def calculate_tip():
    bill = bill_input.value()
    percent = tip_percent_input.value()
    tip = bill * (percent / 100.0)
    total = bill + tip
    tip_amount_display.setValue(tip)
    total_display.setValue(total)

calculate_button.clicked.connect(calculate_tip)

window.show()
app.exec()
