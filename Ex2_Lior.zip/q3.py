import sys
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QDoubleSpinBox

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("Question 3")
window.setGeometry(300, 200, 400, 250)

label1 = QLabel("First Number:", window)
label1.setGeometry(30, 30, 140, 30)

num1 = QDoubleSpinBox(window)
num1.setGeometry(180, 30, 180, 30)
num1.setRange(-100, 100)

label2 = QLabel("Second Number:", window)
label2.setGeometry(30, 75, 140, 30)

num2 = QDoubleSpinBox(window)
num2.setGeometry(180, 75, 180, 30)
num2.setRange(-100, 100)

btn_add = QPushButton("+", window)
btn_add.setGeometry(60, 125, 60, 35)

btn_sub = QPushButton("-", window)
btn_sub.setGeometry(135, 125, 60, 35)

btn_mul = QPushButton("*", window)
btn_mul.setGeometry(210, 125, 60, 35)

btn_div = QPushButton("/", window)
btn_div.setGeometry(285, 125, 60, 35)

label_result = QLabel("Result:", window)
label_result.setGeometry(30, 185, 140, 30)

result_box = QDoubleSpinBox(window)
result_box.setGeometry(180, 185, 180, 30)
result_box.setRange(-10000, 10000)
result_box.setReadOnly(True)
result_box.setStyleSheet("background-color: gray;")

def add():
    val1 = num1.value()
    val2 = num2.value()
    result_box.setValue(val1 + val2)

def subtract():
    val1 = num1.value()
    val2 = num2.value()
    result_box.setValue(val1 - val2)

def multiply():
    val1 = num1.value()
    val2 = num2.value()
    result_box.setValue(val1 * val2)

def divide():
    val1 = num1.value()
    val2 = num2.value()
    if val2 != 0:
        result_box.setValue(val1 / val2)

btn_add.clicked.connect(add)
btn_sub.clicked.connect(subtract)
btn_mul.clicked.connect(multiply)
btn_div.clicked.connect(divide)

window.show()
app.exec()
