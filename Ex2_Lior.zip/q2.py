import sys
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QLineEdit

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("Question 2")
window.setGeometry(300, 200, 450, 150)

label_name = QLabel("Enter your name:", window)
label_name.setGeometry(30, 30, 120, 30)

name_input = QLineEdit(window)
name_input.setGeometry(160, 30, 250, 30)

label_output = QLabel("Greeting:", window)
label_output.setGeometry(30, 80, 120, 30)

output_display = QLineEdit(window)
output_display.setGeometry(160, 80, 250, 30)
output_display.setReadOnly(True)
output_display.setStyleSheet("background-color: gray;")

def show_greeting():
    name = name_input.text()
    output_display.setText(f"Hello {name} your name is {len(name)} letters long")

name_input.returnPressed.connect(show_greeting)

window.show()
app.exec()
