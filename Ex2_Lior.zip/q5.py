import sys
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QSpinBox, QLineEdit

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("Question 5")
window.setGeometry(300, 200, 400, 200)

label_num = QLabel("Enter Number (0-1000):", window)
label_num.setGeometry(30, 30, 160, 30)

num_input = QSpinBox(window)
num_input.setGeometry(200, 30, 160, 30)
num_input.setRange(0, 1000)

check_button = QPushButton("Check", window)
check_button.setGeometry(30, 80, 330, 35)

label_result = QLabel("Result:", window)
label_result.setGeometry(30, 135, 160, 30)

result_display = QLineEdit(window)
result_display.setGeometry(200, 135, 160, 30)
result_display.setReadOnly(True)
result_display.setStyleSheet("background-color: gray;")

# Algorithm explanation:
# A prime number is an integer greater than 1 that is divisible only by 1 and itself.
# Numbers less than 2 (0 and 1) are not prime.
# For numbers 2 and above, we check if any number from 2 up to num - 1 divides it with no remainder.
# If any divisor is found (num % i == 0), the number is not prime.
# If no divisors are found, the number is prime.
def check_prime():
    num = num_input.value()
    
    if num < 2:
        result_display.setText("Not Prime")
        return

    is_prime = True
    for i in range(2, num):
        if num % i == 0:
            is_prime = False
            break

    if is_prime:
        result_display.setText("Prime")
    else:
        result_display.setText("Not Prime")

check_button.clicked.connect(check_prime)

window.show()
app.exec()
