import sys
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QLineEdit

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("Question 1")
window.setGeometry(300, 200, 350, 200)

click_count = 0

button = QPushButton("Click Me", window)
button.setGeometry(50, 20, 250, 35)

label_counter = QLabel("Clicks:", window)
label_counter.setGeometry(50, 70, 100, 30)

counter_display = QLineEdit("0", window)
counter_display.setGeometry(160, 70, 140, 30)
counter_display.setReadOnly(True)
counter_display.setStyleSheet("background-color: gray;")

label_message = QLabel("Message:", window)
label_message.setGeometry(50, 120, 100, 30)

message_display = QLineEdit("", window)
message_display.setGeometry(160, 120, 140, 30)
message_display.setReadOnly(True)
message_display.setStyleSheet("background-color: gray;")

def on_button_clicked():
    global click_count
    click_count = click_count + 1
    counter_display.setText(str(click_count))
    
    if message_display.text() == "":
        message_display.setText("Hello World")
    else:
        message_display.setText("")

button.clicked.connect(on_button_clicked)

window.show()
app.exec()
