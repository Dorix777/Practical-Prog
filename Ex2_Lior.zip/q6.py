import sys
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QDoubleSpinBox

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("Question 6")
window.setGeometry(300, 200, 360, 200)

first_number = 0.0
operation = ""

label_display = QLabel("Display:", window)
label_display.setGeometry(30, 25, 70, 30)

display = QDoubleSpinBox(window)
display.setGeometry(110, 25, 220, 30)
display.setRange(-float('inf'), float('inf'))

btn_add = QPushButton("+", window)
btn_add.setGeometry(30, 75, 65, 35)

btn_sub = QPushButton("-", window)
btn_sub.setGeometry(105, 75, 65, 35)

btn_mul = QPushButton("*", window)
btn_mul.setGeometry(180, 75, 65, 35)

btn_div = QPushButton("/", window)
btn_div.setGeometry(255, 75, 65, 35)

btn_equal = QPushButton("=", window)
btn_equal.setGeometry(30, 125, 140, 40)

btn_cls = QPushButton("CLS", window)
btn_cls.setGeometry(180, 125, 140, 40)

def op_add():
    global first_number, operation
    first_number = display.value()
    operation = "+"

def op_sub():
    global first_number, operation
    first_number = display.value()
    operation = "-"

def op_mul():
    global first_number, operation
    first_number = display.value()
    operation = "*"

def op_div():
    global first_number, operation
    first_number = display.value()
    operation = "/"

def calculate_result():
    global first_number, operation
    second_number = display.value()
    
    if operation == "+":
        display.setValue(first_number + second_number)
    elif operation == "-":
        display.setValue(first_number - second_number)
    elif operation == "*":
        display.setValue(first_number * second_number)
    elif operation == "/":
        if second_number != 0:
            display.setValue(first_number / second_number)

def clear_all():
    global first_number, operation
    first_number = 0.0
    operation = ""
    display.setValue(0.0)

btn_add.clicked.connect(op_add)
btn_sub.clicked.connect(op_sub)
btn_mul.clicked.connect(op_mul)
btn_div.clicked.connect(op_div)
btn_equal.clicked.connect(calculate_result)
btn_cls.clicked.connect(clear_all)

window.show()
app.exec()
